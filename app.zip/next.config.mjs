/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ["tfnexfqnnugbnfogoypl.supabase.co"],
  },
};

export default nextConfig;
